<#
.SYNOPSIS
  Configure un laboratoire Active Directory vulnerable et controlé pour le TP final Master 1.

.DESCRIPTION
  A executer uniquement sur le controleur de domaine DC01 d'un lab isole.
  Le script cree OUs, utilisateurs, groupes, comptes de service, partages, GPO, ACL faibles,
  droits de replication pedagogiques et donnees de contexte.

  Il ne contient aucun code d'exploitation, aucune extraction de secrets et aucune generation de ticket Kerberos.
  Le scenario Golden Ticket est traite par simulation/detection dans le script separe 04-GoldenTicket-Detection-Simulation.ps1.

.PREREQUIS
  - Domaine deja cree, exemple : corp.local
  - Machine deja promue Domain Controller
  - Modules ActiveDirectory et GroupPolicy
  - Execution avec un compte Domain Admin
#>

param(
    [string]$DomainFqdn = "corp.local",
    [string]$NetbiosName = "CORP",
    [string]$BaseOuName = "MockCorp",
    [string]$DefaultPassword = "Password123!",
    [string]$WeakServicePassword = "Service123!",
    [switch]$CreateShares = $true,
    [switch]$ConfigureGPO = $true,
    [switch]$IncludeCriticalPaths = $true
)

$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
Import-Module GroupPolicy

Write-Host "=== MockCorp AD Lab - TP Final ===" -ForegroundColor Cyan
Write-Host "Domaine : $DomainFqdn"
Write-Host "Base OU : $BaseOuName"
Write-Host "Mode critical paths : $IncludeCriticalPaths"
Write-Host ""

$Domain = Get-ADDomain
$DomainDN = $Domain.DistinguishedName
$BaseOU = "OU=$BaseOuName,$DomainDN"

function Test-OUExists($Identity) {
    try { Get-ADOrganizationalUnit -Identity $Identity -ErrorAction Stop | Out-Null; return $true }
    catch { return $false }
}

function New-LabOU {
    param([string]$Name,[string]$Path)
    $dn = "OU=$Name,$Path"
    if (-not (Test-OUExists $dn)) {
        New-ADOrganizationalUnit -Name $Name -Path $Path -ProtectedFromAccidentalDeletion $false
        Write-Host "[OU] Creee : $dn" -ForegroundColor Green
    } else { Write-Host "[OU] Existe : $dn" -ForegroundColor Yellow }
}

function New-LabGroup {
    param([string]$Name,[string]$Path,[string]$Description="",[string]$Scope="Global")
    if (-not (Get-ADGroup -Filter "SamAccountName -eq '$Name'" -ErrorAction SilentlyContinue)) {
        New-ADGroup -Name $Name -SamAccountName $Name -GroupScope $Scope -GroupCategory Security -Path $Path -Description $Description
        Write-Host "[Groupe] Cree : $Name" -ForegroundColor Green
    } else { Write-Host "[Groupe] Existe : $Name" -ForegroundColor Yellow }
}

function New-LabUser {
    param(
        [string]$Sam,[string]$GivenName,[string]$Surname,[string]$Path,[string]$Password,
        [string]$Description="",[bool]$PasswordNeverExpires=$false,[bool]$Enabled=$true
    )
    if (-not (Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue)) {
        $secure = ConvertTo-SecureString $Password -AsPlainText -Force
        New-ADUser -SamAccountName $Sam -UserPrincipalName "$Sam@$DomainFqdn" -Name "$GivenName $Surname" `
            -GivenName $GivenName -Surname $Surname -DisplayName "$GivenName $Surname" -Path $Path `
            -AccountPassword $secure -Enabled $Enabled -ChangePasswordAtLogon $false `
            -PasswordNeverExpires $PasswordNeverExpires -Description $Description
        Write-Host "[Utilisateur] Cree : $Sam" -ForegroundColor Green
    } else { Write-Host "[Utilisateur] Existe : $Sam" -ForegroundColor Yellow }
}

# 1. OUs
if (-not (Test-OUExists $BaseOU)) {
    New-ADOrganizationalUnit -Name $BaseOuName -Path $DomainDN -ProtectedFromAccidentalDeletion $false
    Write-Host "[OU] Creee : $BaseOU" -ForegroundColor Green
}
foreach ($ou in @("Users","Groups","Service Accounts","Workstations","Servers","Privileged","Legacy","Staging","Purple Team")) {
    New-LabOU -Name $ou -Path $BaseOU
}

$UsersOU = "OU=Users,$BaseOU"
$GroupsOU = "OU=Groups,$BaseOU"
$SvcOU = "OU=Service Accounts,$BaseOU"
$PrivOU = "OU=Privileged,$BaseOU"
$LegacyOU = "OU=Legacy,$BaseOU"
$PurpleOU = "OU=Purple Team,$BaseOU"

# 2. Groupes metiers et techniques
$groups = @(
    @("GG_IT_Helpdesk","Support niveau 1 - delegation trop large a analyser"),
    @("GG_Web_Developers","Developpeurs web"),
    @("GG_Finance","Equipe Finance"),
    @("GG_HR","Equipe RH"),
    @("GG_SOC_Readers","Acces lecture logs securite"),
    @("GG_Workstation_Admins","Admins locaux postes - groupe a revoir"),
    @("GG_Legacy_Admins","Groupe historique trop permissif"),
    @("GG_Server_Operators_Junior","Operateurs serveurs junior"),
    @("GG_App_Owners","Responsables applicatifs"),
    @("GG_AD_Replication_Operators","Droits de replication pedagogiques - risque DCSync/Golden Ticket theorique")
)
foreach ($g in $groups) { New-LabGroup -Name $g[0] -Path $GroupsOU -Description $g[1] }

# 3. Utilisateurs standards
$users = @(
    @("adiop","Awa","Diop","GG_HR"),
    @("afall","Awa","Fall","GG_HR"),
    @("bfall","Babacar","Fall","GG_Web_Developers"),
    @("bkeita","Bangaly","Keita","GG_IT_Helpdesk"),
    @("esarr","Elhadji","Sarr","GG_IT_Helpdesk"),
    @("pmballo","Papa Mballo","Thiam","GG_Finance"),
    @("mkone","Mamadou Lamine","Kone","GG_Web_Developers"),
    @("asangare","Aboubacar","Sangare","GG_Web_Developers"),
    @("msalem","Mohamed Salem","Hadrami","GG_SOC_Readers"),
    @("akdieng","Abdou Khadre","Dieng","GG_IT_Helpdesk"),
    @("mseye","Mandinka","Seye","GG_Finance"),
    @("odiouf","Ousseynou","Diouf","GG_SOC_Readers"),
    @("mlbah","Muhammadou Lamin","Bah","GG_App_Owners")
)
foreach ($u in $users) {
    New-LabUser -Sam $u[0] -GivenName $u[1] -Surname $u[2] -Path $UsersOU -Password $DefaultPassword `
        -Description "Compte utilisateur pedagogique - mot de passe initial faible"
    Add-ADGroupMember -Identity $u[3] -Members $u[0] -ErrorAction SilentlyContinue
}

# 4. Comptes privilegies pedagogiques
New-LabUser -Sam "adm.papa" -GivenName "Papa Samba" -Surname "NDIAYE" -Path $PrivOU `
    -Password "P@ssw0rd-Admin-2026!" -Description "Compte admin nominal pedagogique"
Add-ADGroupMember -Identity "Domain Admins" -Members "adm.papa" -ErrorAction SilentlyContinue

New-LabUser -Sam "admin.legacy" -GivenName "Admin" -Surname "Legacy" -Path $PrivOU `
    -Password "Admin2026!" -PasswordNeverExpires $true `
    -Description "Ancien compte Domain Admin - PasswordNeverExpires - cible du chemin DA-01"
Add-ADGroupMember -Identity "Domain Admins" -Members "admin.legacy" -ErrorAction SilentlyContinue
Add-ADGroupMember -Identity "GG_Legacy_Admins" -Members "admin.legacy" -ErrorAction SilentlyContinue

# 5. Comptes de service et Kerberos
New-LabUser -Sam "svc_sql" -GivenName "Service" -Surname "SQL" -Path $SvcOU -Password $WeakServicePassword `
    -PasswordNeverExpires $true -Description "SQL service account - TODO rotate password - Service123!"
New-LabUser -Sam "svc_web" -GivenName "Service" -Surname "Web" -Path $SvcOU -Password $WeakServicePassword `
    -PasswordNeverExpires $true -Description "WebApp legacy service - utilise par ancienne application intranet"
New-LabUser -Sam "svc_legacy" -GivenName "Service" -Surname "Legacy" -Path $SvcOU -Password "Legacy123!" `
    -PasswordNeverExpires $true -Description "Compte legacy sans pre-auth Kerberos - a identifier"
New-LabUser -Sam "svc_backup" -GivenName "Service" -Surname "Backup" -Path $SvcOU -Password "Backup123!" `
    -PasswordNeverExpires $true -Description "Compte sauvegarde - membre replication operators - risque majeur"

setspn -S MSSQLSvc/srv01.corp.local:1433 svc_sql | Out-Null
setspn -S HTTP/webapp.corp.local svc_web | Out-Null
Set-ADAccountControl -Identity "svc_legacy" -DoesNotRequirePreAuth $true
Add-ADGroupMember -Identity "GG_AD_Replication_Operators" -Members "svc_backup" -ErrorAction SilentlyContinue

# 6. Groupes et privileges heritage
Add-ADGroupMember -Identity "Server Operators" -Members "GG_Legacy_Admins" -ErrorAction SilentlyContinue
Add-ADGroupMember -Identity "GG_Workstation_Admins" -Members "GG_IT_Helpdesk" -ErrorAction SilentlyContinue

# 7. Politique de mot de passe volontairement faible
Set-ADDefaultDomainPasswordPolicy -Identity $DomainFqdn -MinPasswordLength 8 -ComplexityEnabled $false `
    -MaxPasswordAge (New-TimeSpan -Days 365) -MinPasswordAge (New-TimeSpan -Days 0) -LockoutThreshold 0

# 8. ACL faibles / chemins DA pedagogiques
if ($IncludeCriticalPaths) {
    Write-Host "[ACL] Chemin DA-01 : Helpdesk peut reinitialiser admin.legacy" -ForegroundColor Cyan
    $adminLegacyDN = (Get-ADUser "admin.legacy").DistinguishedName
    dsacls $adminLegacyDN /G "$NetbiosName\GG_IT_Helpdesk:CA;Reset Password" | Out-Null
    dsacls $adminLegacyDN /G "$NetbiosName\GG_IT_Helpdesk:WP;pwdLastSet" | Out-Null
    dsacls $adminLegacyDN /G "$NetbiosName\GG_IT_Helpdesk:WP;lockoutTime" | Out-Null

    Write-Host "[ACL] Delegation Helpdesk sur OU=Users" -ForegroundColor Cyan
    dsacls $UsersOU /I:S /G "$NetbiosName\GG_IT_Helpdesk:CA;Reset Password;user" | Out-Null
    dsacls $UsersOU /I:S /G "$NetbiosName\GG_IT_Helpdesk:WP;pwdLastSet;user" | Out-Null
    dsacls $UsersOU /I:S /G "$NetbiosName\GG_IT_Helpdesk:WP;lockoutTime;user" | Out-Null

    Write-Host "[ACL] Chemin DA-02 : droits de replication sur le domaine" -ForegroundColor Cyan
    dsacls $DomainDN /G "$NetbiosName\GG_AD_Replication_Operators:CA;Replicating Directory Changes" | Out-Null
    dsacls $DomainDN /G "$NetbiosName\GG_AD_Replication_Operators:CA;Replicating Directory Changes All" | Out-Null
    dsacls $DomainDN /G "$NetbiosName\GG_AD_Replication_Operators:CA;Replicating Directory Changes In Filtered Set" | Out-Null

    Write-Host "[ACL] Delegation faible sur OU Service Accounts" -ForegroundColor Cyan
    dsacls $SvcOU /I:S /G "$NetbiosName\GG_Web_Developers:WP;description;user" | Out-Null
    dsacls $SvcOU /I:S /G "$NetbiosName\GG_Web_Developers:RP;servicePrincipalName;user" | Out-Null
}

# 9. GPO pedagogiques
if ($ConfigureGPO) {
    foreach ($gpo in @("GPO_LAB_Weak_Password_Notice","GPO_LAB_Workstation_Admins_Simulated","GPO_LAB_PurpleTeam_Auditing")) {
        if (-not (Get-GPO -Name $gpo -ErrorAction SilentlyContinue)) { New-GPO -Name $gpo | Out-Null }
    }
    New-GPLink -Name "GPO_LAB_Weak_Password_Notice" -Target $BaseOU -LinkEnabled Yes -ErrorAction SilentlyContinue
    New-GPLink -Name "GPO_LAB_Workstation_Admins_Simulated" -Target "OU=Workstations,$BaseOU" -LinkEnabled Yes -ErrorAction SilentlyContinue
    New-GPLink -Name "GPO_LAB_PurpleTeam_Auditing" -Target $BaseOU -LinkEnabled Yes -ErrorAction SilentlyContinue
    Set-GPO -Name "GPO_LAB_Workstation_Admins_Simulated" -Comment "Simulation : verifier l'appartenance de GG_Workstation_Admins et l'impact des admins locaux." | Out-Null
    Set-GPO -Name "GPO_LAB_PurpleTeam_Auditing" -Comment "GPO pedagogique : audit logon, account management, directory service access." | Out-Null
}

# 10. Partages et fichiers de contexte
if ($CreateShares) {
    $ShareRoot = "C:\MockCorp-Shares"
    $paths = @("IT","Finance","Legacy","PurpleTeam") | ForEach-Object { Join-Path $ShareRoot $_ }
    foreach ($p in $paths) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    @"
MockCorp Internal IT Notes
- Ancienne application webapp.corp.local
- Compte de service historique : svc_web
- Migration prevue vers authentification moderne
- Verifier les delegations sur OU=Service Accounts
"@ | Out-File "$ShareRoot\IT\notes_infra.txt" -Encoding UTF8
    @"
Legacy migration checklist
- admin.legacy encore present
- certains comptes ont PasswordNeverExpires
- des SPN historiques existent
- audit de delegation necessaire
"@ | Out-File "$ShareRoot\Legacy\legacy_migration.txt" -Encoding UTF8
    @"
Golden Ticket Detection Drill - Simulation
Objectif : analyser les traces et mesures defensives liees a une compromission KRBTGT theorique.
Aucune generation de ticket forge n'est demandee dans ce TP.
"@ | Out-File "$ShareRoot\PurpleTeam\golden_ticket_drill.txt" -Encoding UTF8
    if (-not (Get-SmbShare -Name "IT-Share" -ErrorAction SilentlyContinue)) { New-SmbShare -Name "IT-Share" -Path "$ShareRoot\IT" -ReadAccess "Authenticated Users" | Out-Null }
    if (-not (Get-SmbShare -Name "Legacy-Share" -ErrorAction SilentlyContinue)) { New-SmbShare -Name "Legacy-Share" -Path "$ShareRoot\Legacy" -ReadAccess "Authenticated Users" | Out-Null }
    if (-not (Get-SmbShare -Name "PurpleTeam-Share" -ErrorAction SilentlyContinue)) { New-SmbShare -Name "PurpleTeam-Share" -Path "$ShareRoot\PurpleTeam" -ReadAccess "Authenticated Users" | Out-Null }
    if (-not (Get-SmbShare -Name "Finance-Share" -ErrorAction SilentlyContinue)) { New-SmbShare -Name "Finance-Share" -Path "$ShareRoot\Finance" -ReadAccess "$NetbiosName\GG_Finance" | Out-Null }
}

# 11. Audit Windows de base
auditpol /set /category:"Account Logon" /success:enable /failure:enable | Out-Null
auditpol /set /category:"Account Management" /success:enable /failure:enable | Out-Null
auditpol /set /category:"Logon/Logoff" /success:enable /failure:enable | Out-Null
auditpol /set /category:"Policy Change" /success:enable /failure:enable | Out-Null
auditpol /set /category:"Directory Service Access" /success:enable /failure:enable | Out-Null

Write-Host ""
Write-Host "=== Configuration terminee ===" -ForegroundColor Cyan
Write-Host "Mot de passe initial utilisateurs : $DefaultPassword"
Write-Host "Chemin DA-01 : GG_IT_Helpdesk -> ResetPassword sur admin.legacy -> Domain Admin"
Write-Host "Chemin DA-02 : svc_backup / GG_AD_Replication_Operators -> droits replication -> risque KRBTGT/Golden Ticket theorique"
Write-Host "Golden Ticket : utilise le script 04 pour la simulation detection, pas de generation de ticket forge."
Write-Host "Redemarrage du DC conseille." -ForegroundColor Yellow
