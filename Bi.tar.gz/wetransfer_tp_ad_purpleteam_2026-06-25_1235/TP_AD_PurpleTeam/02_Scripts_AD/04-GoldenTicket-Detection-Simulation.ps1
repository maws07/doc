<#
Simulation de traces defensives pour scenario Golden Ticket / KRBTGT.
Ce script NE forge PAS de ticket Kerberos, NE recupere PAS de hash et NE modifie PAS KRBTGT.
Il genere uniquement des observables pedagogiques pour SOC/Purple Team.
#>
param([string]$OutDir="C:\MockCorp-Shares\PurpleTeam")
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
$events = @(
    [pscustomobject]@{Time=(Get-Date).AddMinutes(-30); Host="DC01"; EventId=4662; Source="Directory Service Access"; Account="CORP\svc_backup"; Message="Replication rights used on domain root - Replicating Directory Changes All"; Severity="High"},
    [pscustomobject]@{Time=(Get-Date).AddMinutes(-25); Host="DC01"; EventId=4769; Source="Kerberos"; Account="CORP\unknown-admin"; Message="TGS request with anomalous lifetime and unusual encryption profile - Golden Ticket indicator simulation"; Severity="Critical"},
    [pscustomobject]@{Time=(Get-Date).AddMinutes(-23); Host="SRV01"; EventId=4624; Source="Security"; Account="CORP\unknown-admin"; Message="Logon Type 3 to server using privileged identity outside change window"; Severity="High"},
    [pscustomobject]@{Time=(Get-Date).AddMinutes(-20); Host="DC01"; EventId=4732; Source="Account Management"; Account="CORP\admin.legacy"; Message="Member added to privileged local/global group - simulation"; Severity="High"}
)
$csv = Join-Path $OutDir "golden_ticket_simulated_observables.csv"
$events | Export-Csv $csv -NoTypeInformation -Encoding UTF8
try {
    if (-not [System.Diagnostics.EventLog]::SourceExists("MockCorpADLab")) { New-EventLog -LogName Application -Source "MockCorpADLab" }
    foreach ($e in $events) {
        Write-EventLog -LogName Application -Source "MockCorpADLab" -EventId 9001 -EntryType Warning -Message "OriginalEventId=$($e.EventId); Account=$($e.Account); $($e.Message)"
    }
    Write-Host "Evenements de simulation ecrits dans Application/MockCorpADLab" -ForegroundColor Green
} catch { Write-Host "Ecriture EventLog non disponible : $($_.Exception.Message)" -ForegroundColor Yellow }
Write-Host "CSV genere : $csv" -ForegroundColor Green
