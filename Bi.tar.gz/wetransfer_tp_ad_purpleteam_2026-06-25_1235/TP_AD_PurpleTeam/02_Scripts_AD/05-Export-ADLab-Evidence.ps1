<# Export de preuves defensives et inventaire AD pour rapport. #>
param([string]$OutDir="C:\MockCorp-ADLab-Evidence")
Import-Module ActiveDirectory
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
Get-ADUser -Filter * -Properties Description,PasswordNeverExpires,DoesNotRequirePreAuth,ServicePrincipalName,MemberOf | Select Name,SamAccountName,Description,PasswordNeverExpires,DoesNotRequirePreAuth,ServicePrincipalName | Export-Csv "$OutDir\users_sensitive_flags.csv" -NoTypeInformation -Encoding UTF8
Get-ADGroup -Filter * -SearchBase (Get-ADDomain).DistinguishedName -Properties Members,Description | Select Name,SamAccountName,Description,Members | Export-Csv "$OutDir\groups_inventory.csv" -NoTypeInformation -Encoding UTF8
Get-ADDefaultDomainPasswordPolicy | Out-File "$OutDir\domain_password_policy.txt"
Get-GPO -All | Select DisplayName,Owner,GpoStatus,CreationTime,ModificationTime,Description | Export-Csv "$OutDir\gpo_inventory.csv" -NoTypeInformation -Encoding UTF8
Get-SmbShare | Select Name,Path,Description | Export-Csv "$OutDir\smb_shares.csv" -NoTypeInformation -Encoding UTF8
Write-Host "Preuves exportees dans $OutDir" -ForegroundColor Green
