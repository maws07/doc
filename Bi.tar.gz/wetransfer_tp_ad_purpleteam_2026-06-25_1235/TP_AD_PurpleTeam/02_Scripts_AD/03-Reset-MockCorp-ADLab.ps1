<#
Reset du lab MockCorp AD. A executer uniquement en lab. Supprime OU, GPO et partages crees.
Ne pas executer en production.
#>
param([string]$BaseOuName="MockCorp")
Import-Module ActiveDirectory
Import-Module GroupPolicy
$DomainDN = (Get-ADDomain).DistinguishedName
$BaseOU = "OU=$BaseOuName,$DomainDN"
Write-Host "=== Reset MockCorp AD Lab ===" -ForegroundColor Red
$confirm = Read-Host "Taper RESET pour confirmer la suppression de $BaseOU"
if ($confirm -ne "RESET") { Write-Host "Annule"; exit }
foreach ($share in "IT-Share","Finance-Share","Legacy-Share","PurpleTeam-Share") {
    if (Get-SmbShare -Name $share -ErrorAction SilentlyContinue) { Remove-SmbShare -Name $share -Force }
}
if (Test-Path "C:\MockCorp-Shares") { Remove-Item "C:\MockCorp-Shares" -Recurse -Force }
foreach ($gpo in "GPO_LAB_Weak_Password_Notice","GPO_LAB_Workstation_Admins_Simulated","GPO_LAB_PurpleTeam_Auditing") {
    if (Get-GPO -Name $gpo -ErrorAction SilentlyContinue) { Remove-GPO -Name $gpo }
}
try { Set-ADOrganizationalUnit -Identity $BaseOU -ProtectedFromAccidentalDeletion $false -ErrorAction SilentlyContinue } catch {}
if (Get-ADOrganizationalUnit -Identity $BaseOU -ErrorAction SilentlyContinue) { Remove-ADOrganizationalUnit -Identity $BaseOU -Recursive -Confirm:$false }
Write-Host "Reset termine." -ForegroundColor Green
