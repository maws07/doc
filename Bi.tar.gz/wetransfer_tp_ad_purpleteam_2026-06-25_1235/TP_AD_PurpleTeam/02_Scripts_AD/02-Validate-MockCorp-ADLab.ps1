<# Validation non intrusive du lab MockCorp AD. #>
param([string]$BaseOuName="MockCorp")
Import-Module ActiveDirectory
Import-Module GroupPolicy
$Domain = Get-ADDomain
$DomainDN = $Domain.DistinguishedName
$BaseOU = "OU=$BaseOuName,$DomainDN"
Write-Host "=== Validation MockCorp AD Lab ===" -ForegroundColor Cyan
Write-Host "Domaine : $($Domain.DNSRoot)"
Write-Host "Base OU : $BaseOU"

$checks = @()
function Add-Check($Name,$Status,$Detail){ $script:checks += [pscustomobject]@{Check=$Name;Status=$Status;Detail=$Detail} }
try { Get-ADOrganizationalUnit -Identity $BaseOU | Out-Null; Add-Check "Base OU" "OK" $BaseOU } catch { Add-Check "Base OU" "KO" $_.Exception.Message }
foreach ($g in "GG_IT_Helpdesk","GG_AD_Replication_Operators","GG_Legacy_Admins","GG_Workstation_Admins") {
    try { Get-ADGroup $g | Out-Null; Add-Check "Groupe $g" "OK" "present" } catch { Add-Check "Groupe $g" "KO" "absent" }
}
foreach ($u in "admin.legacy","svc_sql","svc_web","svc_legacy","svc_backup") {
    try { $ad = Get-ADUser $u -Properties PasswordNeverExpires,DoesNotRequirePreAuth,ServicePrincipalName,Description; Add-Check "Compte $u" "OK" $ad.Description } catch { Add-Check "Compte $u" "KO" "absent" }
}
$policy = Get-ADDefaultDomainPasswordPolicy
Add-Check "Password Policy" "INFO" "MinLength=$($policy.MinPasswordLength), Complexity=$($policy.ComplexityEnabled), Lockout=$($policy.LockoutThreshold)"
try { Get-SmbShare -Name IT-Share,Legacy-Share,PurpleTeam-Share -ErrorAction Stop | Out-Null; Add-Check "Partages" "OK" "IT/Legacy/PurpleTeam" } catch { Add-Check "Partages" "INFO" "A verifier sur DC" }
$checks | Format-Table -AutoSize
$Out = "C:\MockCorp-ADLab-Validation.csv"
$checks | Export-Csv $Out -NoTypeInformation -Encoding UTF8
Write-Host "Rapport CSV : $Out" -ForegroundColor Green
