# TP Final AD Purple Team - MockCorp

Package complet pour un TP de consolidation TP9, TP10 et TP11 : Active Directory, privilege escalation, detection, remediation et retest.

## Contenu
- `01_Enonce_Etudiant/` : enonce du TP.
- `02_Scripts_AD/` : configuration automatique du lab AD, validation, reset, export de preuves et simulation Golden Ticket defensive.
- `04_Outils/` : liste d'outils et consignes.
- `05_Modeles_Rapport/` : modele de rapport et tableau de constats.

## Usage rapide
1. Installer un DC Windows Server dans un lab isole et promouvoir le domaine `corp.local`.
2. Copier le dossier `02_Scripts_AD` sur DC01.
3. Ouvrir PowerShell en administrateur de domaine.
4. Executer :

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.-Configure-MockCorp-ADLab.ps1 -DomainFqdn corp.local -NetbiosName CORP
.-Validate-MockCorp-ADLab.ps1
.-GoldenTicket-Detection-Simulation.ps1
```

## Note importante
Le scenario Golden Ticket est fourni sous forme de simulation defensive et d'analyse de chemins de risque. Le package ne contient pas de commande de forge de ticket ni d'extraction de secrets.
