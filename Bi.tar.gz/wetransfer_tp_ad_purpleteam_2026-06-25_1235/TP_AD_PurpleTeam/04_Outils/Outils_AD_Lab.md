# Outils recommandés - TP Final AD Purple Team

## Windows / DC
- Active Directory Users and Computers
- Group Policy Management Console
- PowerShell ActiveDirectory
- Event Viewer
- auditpol
- RSAT

## Poste auditeur
- BloodHound / SharpHound en laboratoire uniquement
- ldapsearch
- smbclient
- nmap
- enum4linux-ng
- PowerShell remoting si explicitement autorisé

## Règles
- Rester sur le réseau du lab.
- Ne pas utiliser d'outils de vol de secrets ou de génération de tickets.
- Prouver par enumeration, ACL, logs, captures et analyse de risque.

